<?php

namespace App\CentralLogics\Restaurant;


class BillingFoodItem
{
    // note
    //  create three class for admin , restaurant & and restaurant to
    // provice their relavent Data

    /*=========// global data //=============*/
    public $foodName = null;
    public $discountBy = null;



    /*=========================
            Restaurant terms
    ===========================*/

    public $restaurantPrice = 0 ;
    public $restaurantDiscount = 0;
    public $restaurantDiscountAmount= 0;
    public $restaurantPriceAfterDiscount = 0;
    public $restaurantPackingCharge = 0;
    public $restaurantPriceAfterPackingCharge = 0;

    /*=========================
            Admin terms
    ===========================*/
    public $adminMargin = 0;
    public $AdminDiscountType = null;
    public $AdminDiscount = 0;
    public $AdminDiscountAmount = 0;
    public $priceAfterAdminDiscount = 0;
    public $adminMarginAfterDiscount = 0;

    /*=========================
            Customer terms
    ===========================*/

    public $foodPrice = 0;
    public $discountAmount = 0;
    public $foodPriceAfterDiscount = 0;
    public $packingCharge = 0;
    public $foodPriceAfterPackingCharge = 0;

    /*=========================
            Calculation terms
    ===========================*/


    public function __construct($data)
    {
        $this->init($data);
    }

    private function init($data){
        try {
        $this->foodName = $data['foodName'];


        //admin test
        $this->adminMargin = $data['adminMargin'] ;
        $this->discountBy = $data['discountBy'];
        $this->AdminDiscountType =  $data['AdminDiscountType']??null;;
        $this->AdminDiscount = $data['AdminDiscount']??0;

        //resturant test

        // $this->discountBy = 'restaurant';
        $this->restaurantPrice = $data['restaurantPrice'];
        $this->restaurantDiscount = $data['restaurantDiscount']??0;
        $this->restaurantPackingCharge = $data['restaurantPackingCharge']??0;
        } catch (\Throwable $th) {
            return $th ;
        }

    }

    public function process()
    {
        $this->subTask_margin();
        $this->subTask_discount();
        $this->setFoodPriceAfterDiscount();
        $this->setMarginAfterDiscount();
        $this->subTask_packingCharge();
        $this->setFoodPriceAfterPackingCharge();

        return $this ;

        // dd($this);
        // return $this->customerData();
        // // return $this->restaurantData();
        // // return $this->adminData();
    }
    private function subTask_margin()
    {
        $this->foodPrice = $this->restaurantPrice + $this->adminMargin;
    }

    private function subTask_discount()
    {
        $temp_restaurantPriceAfterDiscount = $this->restaurantPrice;
        if($this->discountBy == 'restaurant'){
            $this->restaurantDiscountAmount = self::discount_calc($this->restaurantPrice, $this->restaurantDiscount);
            $temp_restaurantPriceAfterDiscount = $this->restaurantPrice -
                            $this->restaurantDiscountAmount;
        }elseif($this->discountBy == 'admin'){
            $this->AdminDiscountAmount = self::discount_calc($this->foodPrice,
                        $this->AdminDiscount ,$this->AdminDiscountType);
        }

        $this->restaurantPriceAfterDiscount = $temp_restaurantPriceAfterDiscount; //this is for restaurant

        // customer discount

        $this->discountAmount = $this->restaurantDiscountAmount + $this->AdminDiscountAmount; // here one at a time can allow discount either admin or restaurant ;

    }

    private function setFoodPriceAfterDiscount()
    {
        //for restaurant
        $this->restaurantPriceAfterDiscount = $this->restaurantPrice - $this->restaurantDiscountAmount;
        //for customer
        $this->foodPriceAfterDiscount = $this->foodPrice - $this->discountAmount;

    }

    private function setMarginAfterDiscount()
    {
        //for admin
        $this->adminMarginAfterDiscount = $this->adminMargin - $this->AdminDiscountAmount;
    }

    private function subTask_packingCharge()
    {
        $this->packingCharge = $this->restaurantPackingCharge;
    }

    private function setFoodPriceAfterPackingCharge()
    {
        //for restaurant
        $this->restaurantPriceAfterPackingCharge = $this->restaurantPriceAfterDiscount + $this->restaurantPackingCharge;

        //for customer
        $this->foodPriceAfterPackingCharge = $this->foodPriceAfterDiscount + $this->packingCharge;
    }

    public static function discount_calc($price, $d_value, $d_type = 'amount')
    {
        $price = (float) $price;
        $d_value = (float) $d_value;

        if ($d_type === 'percent') {
            $dis = ($price * $d_value / 100);
        } else if($d_type === 'amount') {
            $dis = $d_value;
        }else{
            $dis = 0 ;
        }
        return $dis;
    }

    public function customerData(){
        $cdata = new FoodItemDataToCustomer();

        $cdata->foodName = $this->foodName ;
        $cdata->foodPrice = $this->foodPrice ;
        $cdata->discountAmount = $this->discountAmount ;
        $cdata->foodPriceAfterDiscount = $this->foodPriceAfterDiscount ;
        $cdata->packingCharge = $this->packingCharge ;
        $cdata->foodPriceAfterPackingCharge = $this->foodPriceAfterPackingCharge ;

        return $cdata;
    }

    public function restaurantData(){

        $rdata = new FoodItemDataToRestaurant();

        $rdata->foodName = $this->foodName ;
        $rdata->restaurantPrice = $this->restaurantPrice ;
        $rdata->restaurantDiscount = $this->restaurantDiscount ;
        $rdata->restaurantDiscountAmount = $this->restaurantDiscountAmount ;
        $rdata->restaurantPriceAfterDiscount = $this->restaurantPriceAfterDiscount ;
        $rdata->restaurantPackingCharge = $this->restaurantPackingCharge ;
        $rdata->restaurantPriceAfterPackingCharge = $this->restaurantPriceAfterPackingCharge ;

        return $rdata;
    }

    public function adminData(){
        $adata = new FoodItemDataToAdmin();
        $adata->foodName = $this->foodName;
        $adata->adminMargin = $this->adminMargin ;
        $adata->AdminDiscountType = $this->AdminDiscountType ;
        $adata->AdminDiscount = $this->AdminDiscount ;
        $adata->AdminDiscountAmount = $this->AdminDiscountAmount ;
        $adata->priceAfterAdminDiscount = $this->priceAfterAdminDiscount ;
        $adata->adminMarginAfterDiscount = $this->adminMarginAfterDiscount ;

        return $adata;
    }












}
