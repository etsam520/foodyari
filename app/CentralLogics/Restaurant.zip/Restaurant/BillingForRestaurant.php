<?php

namespace App\CentralLogics\Restaurant;

class BillingForRestaurant {
    public $foodItemList = [];
    public $restaurantFoodPriceCollection = 0 ; // here sum of restaurant food price

    public $restaurantCouponDiscount = 0;
    public $restaurantCouponDiscountType = null;
    public $restaurantCouponDiscountAmount = 0;
    public $restaurantPriceAfterCouponDiscount = 0;

    public $commissionChargedByAdmin = 0;
    public $restaurantPriceAfterCommissinChargedByAdmin =0;
    public $restaurantGrossTotal = 0 ;

    public $restaurantGstPercent = 0;
    public $restaurantGstAmount = 0 ;
    public $restaurantReceivableAmount = 0;
    public $restaurantEarning = 0;

    public function __construct()
    {
        return $this;
    }

}

