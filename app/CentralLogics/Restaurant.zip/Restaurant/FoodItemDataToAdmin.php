<?php

namespace App\CentralLogics\Restaurant;



 class FoodItemDataToAdmin
{
    public $foodName =null ;
    public $adminMargin = 0;
    public $AdminDiscountType = null;
    public $AdminDiscount = 0;
    public $AdminDiscountAmount = 0;
    public $priceAfterAdminDiscount = 0;
    public $adminMarginAfterDiscount = 0;

    public function __construct()
    {
        return $this;
    }


}
