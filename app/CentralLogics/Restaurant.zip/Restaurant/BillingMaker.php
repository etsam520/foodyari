<?php

namespace App\CentralLogics\Restaurant;

use App\CentralLogics\Helpers;
use App\Models\CustomerAddress;
use App\Models\Zone;
use Carbon\Carbon;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\Session;

class BillingMaker {

    /*=========================
            Restaurant terms
    ===========================*/
    public $restaurant = null ;

    public $foodItemListDataToRestaurant = [];

    public $restaurantFoodPriceCollection = 0 ; // here sum of restaurant food price

    public $restaurantCouponDiscount = 0;
    public $restaurantCouponDiscountType = null;
    public $restaurantCouponDiscountAmount = 0;
    public $restaurantPriceAfterCouponDiscount = 0;

    public $commissionChargedByAdmin = 0;
    public $restaurantPriceAfterCommissinChargedByAdmin =0;
    public $restaurantGrossTotal = 0 ;

    public $restaurantGstPercent = 0;
    public $restaurantGstAmount = 0 ;
    public $restaurantReceivableAmount = 0;
    public $restaurantEarning = 0;
    /*=========================
            Admin terms
    ===========================*/
    public $foodItemListDataToAdmin = [];
    public $adminMargingCollection = 0;

    public $adminComissionPercent = 0;
    public $adminComissionAmount = 0;
    public $adminMarginAfterComission = 0;

    public $adminCouponDiscountType = null;
    public $adminCouponDiscount = 0;
    public $adminCouponDiscountAmount = 0 ;
    public $adminMarginAfterCouponDiscount = 0;
    public $adminSelfBalanceCouponDiscountAmount = 0;
    public $adminMarginAfterSelfBalanceCouponDiscountAmouont = 0;

    public $grossAdminMargin = 0 ;


    public $adminGstAmount = 0;
    public $adminReceivableAmount = 0;
    public $adminEarning = 0;

    /*=========================
            Customer terms
    ===========================*/
    public $userId = null ;
    public $sendBill = false;
    public $order_to = 'self';

    public $distance = 0 ;
    public $foodItemListDataToCustomer = [];
    public $sumOfFoodPrice = 0 ;

    public $couponDiscount = 0;
    public $couponDiscountType = null ;
    public $couponDiscountAmount = 0 ;
    public $sumOfFoodPriceAfterCouponDiscount = 0;
    public $grossTotal = 0;
    public $gstPercent = 0;
    public $gstAmount = 0;
    public $billingTotal = 0;

    /*=========================
            global  terms
    ===========================*/
    public $couponDiscountBy = null ;
    public $deliveryAddress = null;
    public $zone = null;
    public $deliveryCharge = 0 ;
    public $platformCharge = 0;



    public function __construct()
    {
        $this->couponDiscountBy = "restaurant";
        $this->deliveryCharge = 45 ;
        $this->platformCharge = 20 ;
        $this->restaurantGstPercent = 8 ;
        //restaurnt Test
        $this->restaurantCouponDiscountType = "percent";
        $this->restaurantCouponDiscount = 5 ;
        //admin Test
        $this->adminCouponDiscountType = "percent" ;
        $this->adminCouponDiscount = 5 ;

    }


    public function process() {
        $foodItems =  [];

        $name = ["Jalebi (250gm)" ,"Ras malai" ,"Samosa Chat" ,"Chowmein" ,"Burger" ,"Chole Bhature" ,"Litti With Chole" ,"Samosa With Chole" ,"Litti (Sada)" ,"samosa (Sada)" ];
        $rp =[49,49,55,49,39,49,19,19,15,15];

        $dy =["admin","admin","admin","admin","admin","admin","restaurant","restaurant","restaurant","restaurant"];

        $dt = ["percent","percent","percent","percent","percent","percent","amount","amount","amount","amount"];

        $d = [3,12,10, 22, 12, 16, 24, 11, 9, 10];

        for($i= 0 ; $i < 10 ; $i++){
            $data =  [
                'foodName' => $name[$i],
                'adminMargin' => 20 ,
                'discountBy' => $dy[$i],
                'restaurantPrice' => $rp[$i] ,
            ];
            if($dy[$i] == "admin"){

                $data['AdminDiscountType'] = $dt[$i];
                $data['AdminDiscount'] = $d[$i];
            }else{

                $data['restaurantDiscount'] = $d[$i];
            }

            $data['restaurantPackingCharge'] = 10 ;


            $foodItem = new BillingFoodItem($data);
            $foodItem->process();
            /*========// for restaurant // ===========*/
            $resturantData = $foodItem->restaurantData();
            if($resturantData->restaurantPackingCharge > 0){
                $this->restaurantFoodPriceCollection += $resturantData->restaurantPriceAfterPackingCharge ;
            }else{
                $this->restaurantFoodPriceCollection += $resturantData->restaurantPriceAfterDiscount ;
            }

            $this->foodItemListDataToRestaurant[] = $resturantData ;

            /*========// for admin // ===========*/
            $adminData = $foodItem->adminData() ;
            $this->adminMargingCollection += $adminData->adminMarginAfterDiscount ;

            $this->foodItemListDataToAdmin[] = $adminData;


            /*========// for customer // ===========*/
            $customerData = $foodItem->customerData();
            if($customerData->packingCharge > 0){
                $this->sumOfFoodPrice += $customerData->foodPriceAfterPackingCharge ;
            }else{
                $this->sumOfFoodPrice += $customerData->foodPriceAfterDiscount ;
            }
            $this->foodItemListDataToCustomer[] = $customerData;

        }
        $this->process2();

        return $this;


    }
    public function process2()
    {
        // dd(
        //     $this->foodItemListDataToRestaurant,
        // $this->foodItemListDataToCustomer,
        // $this->foodItemListDataToAdmin) ;

        $this->subTask_couponDiscount();
        $this->setPriceAfterCouponDiscount();
        $this->setDeliveryChargeAndPlatformCharge() ;
        $this->setAdminCommisionOnRestaurant() ;
        $this->subTask_GST() ;
        $this->customerBillPrincing() ;
        $this->subTast_earnings() ;


        // // return $this;
        // dd($this);
    }

    private function subTask_couponDiscount()
    {
        /*=========// for restaurnat //===================*/
        if($this->couponDiscountBy == "restaurant"){
            $this->restaurantCouponDiscountAmount = self::CouponDiscount_calc(
                $this->restaurantFoodPriceCollection, $this->restaurantCouponDiscount, $this->restaurantCouponDiscountType
            );
        }

        /*=========// for admin //===================*/
        if($this->couponDiscountBy == "admin"){
            $this->adminCouponDiscountAmount = self::CouponDiscount_calc(
                $this->sumOfFoodPrice , $this->adminCouponDiscount , $this->adminCouponDiscountType // here sum of food price is of cumtomer food price
            );
        }

        /*=========// for customer //===================*/
        if($this->couponDiscountBy == "restaurant"){
            $this->couponDiscount = $this->restaurantCouponDiscount ;
            $this->couponDiscountType = $this->restaurantCouponDiscountType ;
        }elseif($this->couponDiscountBy ==  "admin"){
            $this->couponDiscount = $this->adminCouponDiscount;
            $this->couponDiscountType = $this->adminCouponDiscountType ;
        }

        $this->couponDiscountAmount  = self::CouponDiscount_calc(
            $this->sumOfFoodPrice , $this->couponDiscount , $this->couponDiscountType
        );

    }

    private function setPriceAfterCouponDiscount()
    {
        /*============// for restaurant //=============*/
        $this->restaurantPriceAfterCouponDiscount = $this->restaurantFoodPriceCollection - $this->restaurantCouponDiscountAmount;

        /*============// for admin //=============*/
        // difference of customer coupon discount and restaurnat coupon discount balcing from margin ;
        $this->adminSelfBalanceCouponDiscountAmount = $this->couponDiscountAmount -
                    ($this->restaurantCouponDiscountAmount + $this->adminCouponDiscountAmount) ;
            //( selfBalace(deduct from admin margin) = customerCouponDiscount - (restaurantCouponDiscountAmount + admounCouponDiscontAmount))

        $this->adminMarginAfterCouponDiscount = $this->adminMargingCollection - $this->adminCouponDiscountAmount ;

        $this->adminMarginAfterSelfBalanceCouponDiscountAmouont = $this->adminMarginAfterCouponDiscount - $this->adminSelfBalanceCouponDiscountAmount ;

        /*============// for customer //=============*/
        $this->sumOfFoodPriceAfterCouponDiscount = $this->sumOfFoodPrice - $this->couponDiscountAmount;

    }

    private function setDeliveryChargeAndPlatformCharge()
    {
        /*============// for customer //=============*/
        $this->grossTotal = $this->sumOfFoodPriceAfterCouponDiscount + $this->deliveryCharge + $this->platformCharge ;

    }

    private function setAdminCommisionOnRestaurant()
    {
        /*============// for restaurant //====================*/
        $this->commissionChargedByAdmin = ($this->restaurantPriceAfterCouponDiscount * $this->adminComissionPercent) / 100 ;
        $this->restaurantPriceAfterCommissinChargedByAdmin = $this->restaurantPriceAfterCouponDiscount - $this->commissionChargedByAdmin ;
        $this->restaurantGrossTotal = $this->restaurantPriceAfterCommissinChargedByAdmin ;

        /*============// for Admin //====================*/
        $this->adminComissionAmount = $this->commissionChargedByAdmin ;
        $this->grossAdminMargin = ($this->adminMarginAfterSelfBalanceCouponDiscountAmouont + $this->platformCharge + $this->deliveryCharge + $this->adminComissionAmount);

    }

    private function subTask_GST( )
    {
        /*============// for customer //====================*/
        $this->gstPercent = $this->restaurantGstPercent ;
        $customerGST = self::gst_calc($this->grossTotal , $this->gstPercent);
        $this->gstAmount =  $customerGST ;

        /*============// for restaurant //====================*/

        $restaurantGST = self::gst_calc($this->restaurantGrossTotal , $this->restaurantGstPercent);
        $this->restaurantGstAmount = $restaurantGST ;

        /*============// for admin //====================*/
        $adminGst = $customerGST - $restaurantGST ;
        $this->adminGstAmount = $adminGst ;

    }

    private function customerBillPrincing( )
    {
        /*============// for customer //====================*/
        $this->billingTotal = $this->gstAmount + $this->grossTotal ;
    }

    private function subTast_earnings( )
    {
        /*============// for restaurant //====================*/
        $this->restaurantReceivableAmount = $this->restaurantGrossTotal + $this->restaurantGstAmount ;
        $this->restaurantEarning = $this->restaurantReceivableAmount - $this->restaurantGstAmount ;

        /*============// for admin //====================*/
        $this->adminReceivableAmount = $this->grossAdminMargin +$this->adminGstAmount ;
        $this->adminEarning = $this->adminReceivableAmount - $this->adminGstAmount ;
    }

    private static function CouponDiscount_calc($price, $d_value, $d_type = 'amount')
    {
        $price = (float) $price;
        $d_value = (float) $d_value;

        if ($d_type === 'percent') {
            $dis = ($price * $d_value / 100);
        } else if($d_type === 'amount') {
            $dis = $d_value;
        }else{
            $dis = 0 ;
        }
        return $dis;
    }



    private static function gst_calc($price, $d_value)
    {
        $price = (float) $price;
        $d_value = (float) $d_value;
        return  ($price * $d_value / 100);
    }

    public function shipping_charge()
    {
        $tempCharge = 0;
        $customerData = [];
        if (!empty($this->userId)) {
            $cookieAddress = Cookie::get('user_location',null);
            if($cookieAddress != null){
                $cookieAddress = json_decode($cookieAddress);
                $customerData['lat'] = $cookieAddress->lat;
                $customerData['lon'] = $cookieAddress->lng;
                $customerData['phone'] = $cookieAddress->phone??null;
                $customerData['address'] = $cookieAddress->address??null;
                $customerData['landmark'] = $cookieAddress->landmark??null;
                $customerData['type'] = $cookieAddress->type??null;

            }else{
                $savedaddress = CustomerAddress::whereHas('customer', function($query) {
                    $query->where('id', $this->userId);
                })->where('is_default',1)->latest()->first();

                $customerData['lat'] = $savedaddress->latitude;
                $customerData['lon'] = $savedaddress->longitude;
                $customerData['phone'] = $savedaddress->phone??null;
                $customerData['address'] = $savedaddress->address??null;
                $customerData['landmark'] = $savedaddress->landmark??null;
                $customerData['type'] = $savedaddress->type??null;

            }
            $zone = Zone::find($this->restaurant->zone_id);
            $this->zone = $zone;

            $userPoint = ['lat' => $customerData['lat'], 'lon' => $customerData['lon']];
            $restaurantPoint = ['lat' => $this->restaurant->latitude, 'lon' => $this->restaurant->longitude];

            $this->distance = Helpers::haversineDistance($userPoint, $restaurantPoint);

            $addressData = [
                            'position' => $userPoint,
                            'stringAddress' => $customerData['address'],
                            'landmark' => $customerData['landmark'],
                            'type' => $customerData['type'],
                            ];
            if (Session::has('loved_one_data')) {
                $loved_one_data = Session::get('loved_one_data',null);
                $addressData['contact_person_name'] = $loved_one_data['name'];
                $addressData['contact_person_number'] = $loved_one_data['name'];

                $this->sendBill = $loved_one_data['sendBill'];
                $this->order_to = "loved_one" ;

            }

            $this->deliveryAddress = json_encode($addressData);


            $tempCharge = number_format(($zone->per_km_shipping_charge * $this->distance), 2, '.', '') ;

        }
        // dd($tempCharge);
        if($tempCharge > $zone->maximum_shipping_charge){
            $this->deliveryCharge = $zone->maximum_shipping_charge;
        }elseif($tempCharge > $zone->minimum_shipping_charge){
            $this->deliveryCharge = $tempCharge;
        }else{
            $this->deliveryCharge = $zone->minimum_shipping_charge;
        }
    }
    private function couponsApply()
    {
        $coupons = Cache::get('applied_coupons', []);
        // dd($this->product_price_after_coupon_discount);
        foreach ($coupons as $key => $coupon) {
            $startDate = Carbon::parse($coupon->start_date);
            $expireDate = Carbon::parse($coupon->expire_date);

            if ($expireDate->isPast(Carbon::now())) {
                unset($coupons[$key]);
                continue;
            }

            $basePrice = max($this->product_price_after_discount_on_food, $this->product_price_after_coupon_discount);

            if ($basePrice > $coupon->min_purchase) {
                if ($coupon->discount_type == 'amount') {
                    $couponDiscountPrice = $coupon->discount;
                } else {
                    $couponDiscountPrice = ($basePrice * $coupon->discount) / 100;
                }

                $this->tempCouponDiscount = min($couponDiscountPrice, $coupon->max_discount);
                $this->couponDiscount += $this->tempCouponDiscount;

                $appliedCoupon = [
                    'id' => $coupon->id, 'code' => $coupon->code, 'couponDiscount' => $this->tempCouponDiscount,'created_by' => $coupon->created_by
                ];
                $this->couponDetails[] = $appliedCoupon;

            } else {
                unset($coupons[$key]); // Remove coupons that do not meet the minimum purchase requirement
            }
        }

        // Cache::put('applied_coupons', array_values($coupons));
        return $this;
    }

    public function subTast_platformCharge(){
        $this->platformCharge = $this->zone->platform_charge_original;
    }



    public function adminBillData()
    {
        $a_bill = new BillingForAdmin();
        $a_bill->foodItemList = $this->foodItemListDataToAdmin ;

        $a_bill->adminMargingCollection = $this->adminMargingCollection ;
        $a_bill->adminComissionPercent = $this->adminComissionPercent ;
        $a_bill->adminComissionAmount = $this->adminComissionAmount ;
        $a_bill->adminMarginAfterComission = $this->adminMarginAfterComission ;
        $a_bill->adminCouponDiscountType = $this->adminCouponDiscountType ;
        $a_bill->adminCouponDiscount = $this->adminCouponDiscount ;
        $a_bill->adminCouponDiscountAmount = $this->adminCouponDiscountAmount ;
        $a_bill->adminMarginAfterCouponDiscount = $this->adminMarginAfterCouponDiscount ;
        $a_bill->adminSelfBalanceCouponDiscountAmount = $this->adminSelfBalanceCouponDiscountAmount ;
        $a_bill->adminMarginAfterSelfBalanceCouponDiscountAmouont = $this->adminMarginAfterSelfBalanceCouponDiscountAmouont ;
        $a_bill->grossAdminMargin = $this->grossAdminMargin ;
        $a_bill->adminGstAmount = $this->adminGstAmount ;
        $a_bill->adminReceivableAmount = $this->adminReceivableAmount ;
        $a_bill->adminEarning = $this->adminEarning ;

        return $a_bill ;

    }

    public function restaurnatBillData()
    {
        $r_bill = new BillingForRestaurant();
        $r_bill->foodItemList = $this->foodItemListDataToAdmin ;
        $r_bill->restaurantFoodPriceCollection = $this->restaurantFoodPriceCollection ;

        $r_bill->restaurantCouponDiscount = $this->restaurantCouponDiscount ;
        $r_bill->restaurantCouponDiscountType = $this->restaurantCouponDiscountType ;
        $r_bill->restaurantCouponDiscountAmount = $this->restaurantCouponDiscountAmount ;
        $r_bill->restaurantPriceAfterCouponDiscount = $this->restaurantPriceAfterCouponDiscount ;

        $r_bill->commissionChargedByAdmin = $this->commissionChargedByAdmin ;
        $r_bill->restaurantPriceAfterCommissinChargedByAdmin = $this->restaurantPriceAfterCommissinChargedByAdmin ;
        $r_bill->restaurantGrossTotal = $this->restaurantGrossTotal ;

        $r_bill->restaurantGstPercent = $this->restaurantGstPercent ;
        $r_bill->restaurantGstAmount = $this->restaurantGstAmount ;
        $r_bill->restaurantReceivableAmount = $this->restaurantReceivableAmount ;
        $r_bill->restaurantEarning = $this->restaurantEarning ;

        return $r_bill ;
    }
    public function customerBillData()
    {
        $c_bill = new BillingForCustomer();
        $c_bill->foodItemList = $this->foodItemListDataToCustomer ;

        $c_bill->sumOfFoodPrice = $this->sumOfFoodPrice ;
        $c_bill->couponDiscount = $this->couponDiscount ;
        $c_bill->couponDiscountType = $this->couponDiscountType ;
        $c_bill->couponDiscountAmount = $this->couponDiscountAmount ;
        $c_bill->sumOfFoodPriceAfterCouponDiscount = $this->sumOfFoodPriceAfterCouponDiscount ;
        $c_bill->grossTotal = $this->grossTotal ;
        $c_bill->gstPercent = $this->gstPercent ;
        $c_bill->gstAmount = $this->gstAmount ;
        $c_bill->billingTotal = $this->billingTotal ;

        return $c_bill;
    }

}
