<?php

namespace App\CentralLogics\Restaurant;

class BillingForAdmin {

    public $foodItemList = [];
    public $adminMargingCollection = 0;

    public $adminComissionPercent = 0;
    public $adminComissionAmount = 0;
    public $adminMarginAfterComission = 0;

    public $adminCouponDiscountType = null;
    public $adminCouponDiscount = 0;
    public $adminCouponDiscountAmount = 0 ;
    public $adminMarginAfterCouponDiscount = 0;
    public $adminSelfBalanceCouponDiscountAmount = 0;
    public $adminMarginAfterSelfBalanceCouponDiscountAmouont = 0;

    public $grossAdminMargin = 0 ;


    public $adminGstAmount = 0;
    public $adminReceivableAmount = 0;
    public $adminEarning = 0;

    public function __construct()
    {
        return $this;
    }
}
