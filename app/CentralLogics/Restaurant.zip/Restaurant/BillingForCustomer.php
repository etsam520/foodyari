<?php

namespace App\CentralLogics\Restaurant;

class BillingForCustomer {
    public $foodItemList = [];

    public $sumOfFoodPrice = 0 ;

    public $couponDiscount = 0;
    public $couponDiscountType = null ;
    public $couponDiscountAmount = 0 ;
    public $sumOfFoodPriceAfterCouponDiscount = 0;
    public $grossTotal = 0;
    public $gstPercent = 0;
    public $gstAmount = 0;
    public $billingTotal = 0;

    public function __construct()
    {
        return $this;
    }

}
